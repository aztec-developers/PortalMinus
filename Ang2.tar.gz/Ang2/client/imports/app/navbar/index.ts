import { NavbarComponent } from './navbar.component';

export const NAVBAR_DECLARATIONS = [
  NavbarComponent
];
