import { Component } from '@angular/core';

import template from './navbar.component.html';

@Component({
  selector: 'navbar',
  template
})
export class NavbarComponent {}
