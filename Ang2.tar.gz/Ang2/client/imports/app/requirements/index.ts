import { RequirementsComponent } from './requirements.component';

export const REQUIREMENTS_DECLARATIONS = [
  RequirementsComponent
];
