import { Component } from '@angular/core';

import template from './requirements.component.html';

@Component({
  selector: 'requirements',
  template
})
export class RequirementsComponent {}
