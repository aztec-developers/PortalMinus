import { Component } from '@angular/core';

import template from './currentsemester.component.html';

@Component({
  selector: 'currentsemester',
  template
})
export class CurrentSemesterComponent {}
