import { SemesterComponent } from './semester.component';

export const SEMESTER_DECLARATIONS = [
  SemesterComponent
];
