import { Component } from '@angular/core';

import template from './pastsemester.component.html';

@Component({
  selector: 'pastsemester',
  template
})
export class PastSemesterComponent {}
