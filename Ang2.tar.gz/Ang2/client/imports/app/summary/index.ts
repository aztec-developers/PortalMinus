import { SummaryComponent } from './summary.component';

export const SUMMARY_DECLARATIONS = [
  SummaryComponent
];
