import { Component } from '@angular/core';

import template from './summary.component.html';

@Component({
  selector: 'summary',
  template
})
export class SummaryComponent {}
