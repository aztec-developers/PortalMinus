import { TodoComponent } from './todo.component';

export const TODO_DECLARATIONS = [
  TodoComponent
];
