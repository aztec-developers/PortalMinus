import { Component } from '@angular/core';

import template from './todo.component.html';

@Component({
  selector: 'todo',
  template
})
export class TodoComponent {}
